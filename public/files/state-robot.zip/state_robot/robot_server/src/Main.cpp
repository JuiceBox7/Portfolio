#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <chrono>
#include <cstdint>

#include "../include/Robot.h"

#define TRUE 1
#define FALSE 0
#define PORT 8888

int main(int argc, char * argv[]) {

	// use these strings to indicate the state transitions
	// the robot progresses through.  Do not modify these strings

	std::string robot_waiting = "The robot is waiting";
	std::string robot_moving = "The robot is moving";

	std::string robot_finished_waiting = "The robot finished waiting";
	std::string robot_finished_moving = "The robot finished moving";

	std::string robot_began_waiting = "The robot began waiting";
	std::string robot_begin_moving = "The robot begain moving";

	int server_fd, new_socket;
	char buf[1024] = {0};
	struct sockaddr_in address;
	int opt = true;

	if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		perror("Socket failed");
		exit(EXIT_FAILURE);
	}

	setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt));

	address.sin_family = AF_INET;
	address.sin_addr.s_addr = INADDR_ANY;
	address.sin_port = htons(PORT);

	if (bind(server_fd, (struct sockaddr*)&address, sizeof(address)) < 0) {
		std::cout << "Bind failed" << std::endl;
		exit(EXIT_FAILURE);
	}

	if (listen(server_fd, 3) < 0) {
		std::cout << "Error listening" << std::endl;
		exit(EXIT_FAILURE);
	}

	socklen_t addrlen = sizeof(address);

	std::shared_ptr<StateMachine> sm = std::make_shared<StateMachine>();

    std::shared_ptr<TimedState> s0 = std::make_shared<TimedState>();
    s0->set_state_name("waiting state");
    s0->set_verb_name("waiting");
    s0->set_owner(sm);

    std::shared_ptr<TimedState> s1 = std::make_shared<TimedState>();
    s1->set_state_name("moving state");
    s1->set_verb_name("moving");
    s1->set_owner(sm);

    s0->set_next_state("done", s1);
    s1->set_next_state("done", s0);
	
    sm->set_current_state(s0);

	if ((new_socket = accept(server_fd, (struct sockaddr*)&address, &addrlen)) < 0) {
		std::cout << "Error in accept" << std::endl;
		exit(EXIT_FAILURE);
	}

	bool check = false;

	std::cout << robot_began_waiting << std::endl;
	
	while (true) {
		int valread = read(new_socket, buf, 1024);
		small_world::SM_Event se;
		se.ParseFromString(buf);
		sm->tick(se);
	}

	close(new_socket);
	close(server_fd);

	return EXIT_SUCCESS;
}
