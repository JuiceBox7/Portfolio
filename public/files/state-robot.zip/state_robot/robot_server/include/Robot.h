#pragma once

#include <string.h>
#include <iostream>
#include <stdlib.h>
#include <map>

#include "Message.h"

class StateMachine;

class RobotState {
    uint64_t initial_time = 0;
    uint64_t current_time = 0;
    std::string state_name;
    std::string verb_name;

    public:
    	std::map<std::string, std::shared_ptr<RobotState>> next_states;
        std::shared_ptr<StateMachine> owner;
        uint64_t get_elapsed() {
            return current_time - initial_time;
        }

        void set_state_name(const std::string &name) {
            state_name = name;
        }

        void set_verb_name(const std::string &verb) {
            verb_name = verb;
        }

        void set_owner(const std::shared_ptr<StateMachine> sm) {
            owner = sm;
        }

        std::string get_state_name() {
            return state_name;
        }

        std::string get_verb_name() {
            return verb_name;
        }

        void set_next_state(const std::string &state_name, std::shared_ptr<RobotState> state) {
            next_states[state_name] = state;
        }

        std::shared_ptr<RobotState> get_next_state(const std::string &transition_name) {
            std::map<std::string, std::shared_ptr<RobotState>>::iterator it = next_states.find(transition_name);
            if (it == next_states.end()) return nullptr;
            return it->second;
        }

        virtual void tick(const small_world::SM_Event &e) {
            if (initial_time == 0) initial_time = e.event_time();
            current_time = e.event_time();
            decide_action(get_elapsed());
        }

        virtual void decide_action(uint64_t elapsed) = 0;
};


class Tickable {
    uint64_t last_tick_time = 0;

    public:
        void tick(const small_world::SM_Event &event) {
            last_tick_time = event.event_time();
        }
};

class StateMachine : public Tickable {
    public:
        std::shared_ptr<RobotState> current_state;
        virtual void tick(const small_world::SM_Event &event) {
            Tickable::tick(event);
            if (current_state != nullptr) current_state->tick(event);
        }

        virtual void set_current_state(std::shared_ptr<RobotState> cs) {
            current_state = cs;
        }
};

class TimedState : public RobotState {
    std::string state_name;
    std::string verb_name;
    uint64_t time_to_wait = 2000;

    public:
        void set_time_to_wait(uint64_t time) {
            time_to_wait = time;
        }

        virtual void decide_action(uint64_t duration) {
            if (duration < time_to_wait) {
                std::cout << "Robot is " << get_verb_name() << std::endl;
                return;
            }

            std::shared_ptr<RobotState> next = get_next_state("done");
            if (next == nullptr) {
                std::cout << "Can't get a next state to go to" << std::endl;
                return;
            }

            std::cout << "The robot finished " << owner->current_state->get_verb_name() << std::endl;
            std::cout << "The robot began " << next->get_verb_name() << std::endl;
            owner->set_current_state(next);
        }
};
