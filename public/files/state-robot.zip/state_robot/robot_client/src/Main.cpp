#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <chrono>
#include <cstdint>
#include <fstream>

#include "../include/Message.h"

using namespace google::protobuf::io;

#define TRUE   1
#define FALSE  0
#define PORT 8888

uint64_t timeSinceEpochMillisec() {
	using namespace std::chrono;
	return duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
}

int main(int argc, char const* argv[])
{
    int status, valread, client_fd;
    struct sockaddr_in server_address;
    std::string hello("Hello from client");

    char buf[1024] = {0};
    if ((client_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
	    std::cout << "\n Socket creation error\n" << std::endl;
        return -1;
    }

    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(PORT);

    // Convert IPv4 and IPv6 addresses from text to binary
    // form
    if (inet_pton(AF_INET, "127.0.0.1", &server_address.sin_addr)
        <= 0) {
        std::cout <<
            "\nInvalid address/ Address not supported \n" << std::endl;
        return -1;
    }

    if ((status
         = connect(client_fd, (struct sockaddr*)&server_address,
                   sizeof(server_address)))
        < 0) {
	    std::cout << "\nConnection Failed \n" << std::endl;
        return -1;
    }

    while (true) {
        sleep(5);
        small_world::SM_Event se;
        se.set_event_type("tick");
        se.set_event_time(timeSinceEpochMillisec());

        std::string binary;
        se.SerializeToString(&binary);
        send(client_fd, binary.c_str(), sizeof(binary), 0);
    }

    // closing the connected socket
    close(client_fd);
    return 0;
}
