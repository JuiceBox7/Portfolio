#pragma once
#include "../src/generated/Message.pb.h"

