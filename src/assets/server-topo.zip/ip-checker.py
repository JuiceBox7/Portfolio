import sys

def convert_to_binary(address):
    binary_address = []
    for i in range(8):
        if(address % 2 == 1):
            binary_address.append(1)
        else:
            binary_address.append(0)
        address = int(address / 2)
    binary_address.reverse()
    return binary_address

def valid_ip(subnet, mask, ip):
    ip_bi = []
    sub_bi = []
    for i in range(4):
        temp = convert_to_binary(int(ip[i]))
        temp2 = convert_to_binary(int(subnet[i]))
        for j in range(8):
            ip_bi.append(temp[j])
            sub_bi.append(temp2[j])
    for i in range(mask):
        if(sub_bi[i] != ip_bi[i]):
            return False
    return True

def main():
    subnet = sys.argv[1].split('.')
    mask = int(sys.argv[2].replace('/', ''))
    ip = sys.argv[3].split('.')
    if(valid_ip(subnet, mask, ip)):
        print(sys.argv[3], 'is valid on subnet', sys.argv[1])
    else:
        print(sys.argv[3], 'is invalid on subnet', sys.argv[1])

if __name__ == "__main__":
    main()