from socket import *
import sys
import os
import argparse as ap
from datetime import datetime
import csv

MIME = {'.csv': 'text/csv', '.png': 'image/png', '.jpg': 'image/jpeg',
        '.gif': 'image/gif', '.zip': 'application/zip', '.txt': 'text/plain',
            '.html': 'text/html', '.doc': 'application/msword', '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'}

STATUS = {'200': '200 OK', '404': '404 Not Found', '501': '501 Not Implemented',
          '505': '505 HTTP Version Not Supported'}

LOCALHOST = '127.0.0.1'

def writeToCSV(server_port, client_info, resource, status, content_length):
  serverIP = LOCALHOST
  clientIP = client_info[0]
  clientPort = client_info[1]
  message = 'Client request served', '4-Tuple:', serverIP, server_port, clientIP,\
      clientPort,'Requested URL', resource, status, 'Bytes transmitted:', content_length
  
  try:
    f = open('jumlaraSocketOutput.csv', 'a') # appends to file if exists
  except FileNotFoundError:
    f = open('jumlaraSocketOutput.csv', 'w')

  writer = csv.writer(f)
  writer.writerow(message)

  f.close()

def writeHTTPResponse(response):
  try:
    f = open('jumlaraHTTPResponses.txt', 'a')
  except FileNotFoundError:
    f = open('jumlaraHTTPResponses.txt', 'w')

  f.write(response)
  f.close()

def handleClient(client_connection, directory, server_port, client_info):
  while True:
    request = client_connection.recv(4096).decode()
    if request == '': # checks for EOF 
      break

    splitrequest = request.split('\r\n')[0].split(' ')
    method, resource, version = splitrequest[0], splitrequest[1], splitrequest[2]
    resource = resource[1:]
    
    url = os.path.join(directory, resource)

    if validHTTP(method, version):
      handleRequest(client_connection, resource, url, server_port, client_info)
      break

    elif version != 'HTTP/1.1':
      statusLine = 'HTTP/1.1 ' + STATUS.get('505')
      httpResponse = statusLine + '\r\n'
      date = datetime.utcnow().strftime('%a, %d %b %G %T %Z')
      httpResponse = httpResponse + 'Date: ' + date + 'GMT\r\n'
      httpResponse = httpResponse + 'Content-Length: 0\r\n'
      httpResponse = httpResponse + 'Connection: Close\r\n' + '\r\n'
      client_connection.send(httpResponse.encode())
      writeToCSV(server_port, client_info, resource, statusLine, '0')
      writeHTTPResponse(httpResponse)
      break

    elif method != 'GET':
      statusLine = 'HTTP/1.1 ' + STATUS.get('501')
      httpResponse = statusLine + '\r\n'
      date = datetime.utcnow().strftime('%a, %d %b %G %T %Z')
      httpResponse = httpResponse + 'Date: ' + date + 'GMT\r\n'
      httpResponse = httpResponse + 'Content-Length: 0\r\n'
      httpResponse = httpResponse + 'Connection: Close\r\n' + '\r\n'
      client_connection.send(httpResponse.encode())
      writeToCSV(server_port, client_info, resource, statusLine, '0')
      writeHTTPResponse(httpResponse)
      break

  client_connection.close()

def validHTTP(method, version):
  if method == 'GET' and version == 'HTTP/1.1':
    return True
  return False

def handleRequest(client_connection, resource, url, server_port, client_info):
  splitFile = os.path.splitext(resource)
  fileExtension = splitFile[1]
  date = datetime.utcnow().strftime('%a, %d %b %G %T %Z')

  if os.path.isfile(url):
    f = open(url, 'rb')
    contents = f.read()
    f.close()

  else:
    statusLine = 'HTTP/1.1 ' + STATUS.get('404')
    httpResponse = statusLine + '\r\n'
    httpResponse = httpResponse + 'Date: ' + date + 'GMT\r\n'
    httpResponse = httpResponse + 'Content-Length: 0\r\n'
    httpResponse = httpResponse + 'Connection: Close\r\n' + '\r\n'
    client_connection.send(httpResponse.encode())
    writeToCSV(server_port, client_info, resource, statusLine, '0')
    writeHTTPResponse(httpResponse)
    return

  statusLine = 'HTTP/1.1 ' + STATUS.get('200')
  httpResponse = statusLine + '\r\n'
  httpResponse = httpResponse + 'Date: ' + date + 'GMT\r\n'
  timestamp = os.path.getmtime(url)
  lastmodified = datetime.utcfromtimestamp(timestamp).strftime(('%a, %d %b %G %T %Z'))
  httpResponse = httpResponse + 'Last-Modified: ' + lastmodified + 'GMT\r\n'
  contentLength = str(len(contents))
  httpResponse = httpResponse + 'Content-Length: ' + contentLength + '\r\n'
  contenttype = MIME.get(fileExtension)
  httpResponse = httpResponse + 'Content-Type: ' + contenttype + '\r\n'
  httpResponse = httpResponse + 'Connection: Close\r\n' + '\r\n'
  writeHTTPResponse(httpResponse)
  httpResponse = httpResponse.encode() + contents
  client_connection.send(httpResponse)
  writeToCSV(server_port, client_info, resource, statusLine, contentLength)
  return

def main():
  argparser = ap.ArgumentParser()
  argparser.add_argument('-p', '--port', type=int, required=True)
  argparser.add_argument('-d', '--directory', type=str, required=True)
  args = argparser.parse_args()

  if args.port > 65535:
    print('Error: Not a valid port!', file=sys.stderr)
    exit()

  if not os.path.exists(args.directory):
    print('Error: No such directory exists!', file=sys.stderr)
    exit()

  serverSocket = socket(AF_INET, SOCK_STREAM)
  try:
    serverSocket.bind(('127.0.0.1', args.port))
    serverSocket.listen(1)

  except error:
    print('Error: Failed to bind socket!', file=sys.stderr)
    exit()
  
  ipaddress = serverSocket.getsockname()
  print('Welcome socket created:', ipaddress[0], ipaddress[1], file=sys.stdout)
  
  while True:
    connectionSocket, addr = serverSocket.accept()
    print('Connection requested from', addr[0], addr[1], file=sys.stdout)
    handleClient(connectionSocket, args.directory, args.port, addr)
    print('Connection to', addr[0], addr[1], 'is closed', file=sys.stdout)
  
if __name__ == '__main__':
  main()
