from pox.core import core

import pox.openflow.libopenflow_01 as of

# Dictionarys for each subnets' devices' ip addresses, and end ports.
SALES = {'10.0.0.10':2, '10.0.0.9':4, '10.0.0.8':6}
OT = {'10.0.3.7':2, '10.0.3.6':4}
IT = {'10.0.2.5':2, '10.0.2.4':4}
DATA = {'10.0.1.3':2, '10.0.1.2':4, '10.0.1.1':6}

log = core.getLogger()

class Routing (object):
  def __init__ (self, connection):
    self.connection = connection
    connection.addListeners(self)

  def accept(self, packet, packet_in, port): # accepts packet and sends it through
    msg = of.ofp_flow_mod()
    msg.match = of.ofp_match.from_packet(packet)
    msg.data = packet_in
    action = of.ofp_action_output(port=port)
    msg.actions.append(action)
    self.connection.send(msg)

  def do_routing (self, packet, packet_in, port_on_switch, switch_id):
    ip = None
    if packet.type == packet.IP_TYPE: # checks type of packet
      if packet.find('ipv4'): # checks if packet is an ipv4 packet
        ip = packet.payload
    if ip is not None:
      source = str(ip.srcip)
      dest = str(ip.dstip)

      if packet.find('icmp'):
        if source in SALES or source in OT or source in IT: # rule 1
          if dest in SALES or dest in OT or dest in IT: # rule 1

            if switch_id == 5: # checks if in core switch
              if dest in SALES: 
                self.accept(packet, packet_in, 10) # routes to correct switch
              if dest in OT:
                self.accept(packet, packet_in, 20)
              if dest in IT:
                self.accept(packet, packet_in, 30)

            if switch_id == 1: # checks if in switch 1
              if dest in SALES: # checks if dest is in same subnet
                end_port = SALES.get(dest) # if so forwards to correct end port
                self.accept(packet, packet_in, end_port)
              else:
                self.accept(packet, packet_in, 11) # otherwise, forwards to core

            if switch_id == 2: # checks if in switch 2
              if dest in OT: 
                end_port = OT.get(dest) 
                self.accept(packet, packet_in, end_port) # forwards to device
              else:
                self.accept(packet, packet_in, 12) # forwards to core

            if switch_id == 3: # checks if in switch 3
              if dest in IT:
                end_port = IT.get(dest)
                self.accept(packet, packet_in, end_port) # forwards to device
              else:
                self.accept(packet, packet_in, 13) # forwards to core

      if packet.find('tcp'):
        if source in DATA or source in OT or source in IT: # rule 2
          if dest in DATA or dest in OT or dest in IT: # rule 2

            if switch_id == 5: # checks if in core switch
              if dest in DATA:
                self.accept(packet, packet_in, 40) # routes to correct switch
              if dest in OT:
                self.accept(packet, packet_in, 20)
              if dest in IT:
                self.accept(packet, packet_in, 30)

            if switch_id == 4: # checks if in switch 4 
              if dest in DATA:
                end_port = DATA.get(dest)
                self.accept(packet, packet_in, end_port) # forwards to device
              else:
                self.accept(packet, packet_in, 14) # forwards to core

            if switch_id == 2: # checks if in switch 2
              if dest in OT:
                end_port = OT.get(dest)
                self.accept(packet, packet_in, end_port) # forwards to device
              else:
                self.accept(packet, packet_in, 12) # forwards to core

            if switch_id == 3: # checks if in switch 3
              if dest in IT:
                end_port = IT.get(dest)
                self.accept(packet, packet_in, end_port) # forwards to device
              else:
                self.accept(packet, packet_in, 13) # forwards to core

      if packet.find('udp'):
        if source in DATA or source in SALES: # rule 3
          if dest in DATA or dest in SALES: # rule 3

            if switch_id == 5: # checks if in core switch
              if dest in DATA:
                self.accept(packet, packet_in, 40) # forwards to correct switch
              if dest in SALES:
                self.accept(packet, packet_in, 10)

            if switch_id == 4: # checks if in switch 4
              if dest in DATA:
                end_port = DATA.get(dest)
                self.accept(packet, packet_in, end_port) # forwards to device
              else:
                self.accept(packet, packet_in, 14) # forwards to core

            if switch_id == 1: # checks if in switch 1
              if dest in SALES:
                end_port = SALES.get(dest)
                self.accept(packet, packet_in, end_port) # forwards to device
              else:
                self.accept(packet, packet_in, 11) # forwards to core
    return # rule 4

  def _handle_PacketIn (self, event):
    packet = event.parsed
    if not packet.parsed:
      log.warning("Ignoring incomplete packet")
      return

    packet_in = event.ofp
    self.do_routing(packet, packet_in, event.port, event.dpid)

def launch ():
  def start_switch (event):
    log.debug("Controlling %s" % (event.connection,))
    Routing(event.connection)
  core.openflow.addListenerByName("ConnectionUp", start_switch)