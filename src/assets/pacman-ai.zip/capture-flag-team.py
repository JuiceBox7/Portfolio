from pacai.agents.capture.reflex import ReflexCaptureAgent
from pacai.core.directions import Directions

class Agent1(ReflexCaptureAgent):
    def __init__(self, index, **kwargs):
        super().__init__(index)

    def getFeatures(self, gameState, action):
        features = {}
        successor = self.getSuccessor(gameState, action)
        myState = successor.getAgentState(self.index)
        features['successorScore'] = self.getScore(successor)

        # Compute distance to the nearest food.
        foodList = self.getFood(successor).asList()
        enemies = [successor.getAgentState(i) for i in self.getOpponents(successor)]
        ghosts = [a for a in enemies if a.isGhost()
                  and a.getPosition() is not None and not a.isScared()]
        myPos = successor.getAgentState(self.index).getPosition()

        if (len(ghosts) > 0):
            g_dis = min([(self.getMazeDistance(myPos, g.getPosition()))
                         for g in ghosts])  # changed to max
            features['ghost_dist'] = g_dis

        if myState.isGhost():
            features['isGhost'] = 1

        if (len(foodList) > 0):
            minDistance = min([self.getMazeDistance(myPos, food) for food in foodList])
            features['distanceToFood'] = minDistance

        if (action == Directions.STOP):
            features['stop'] = 1

        return features

    def getWeights(self, gameState, action):
        return {
            'successorScore': 1000,  # default 1000
            'distanceToFood': -7,  # default was -5
            'ghost_dist': -5,  # default -3
            'stop': -1000,  # default -1000
            'isGhost': -1  # default -1
        }


class Agent2(ReflexCaptureAgent):
    def __init__(self, index, **kwargs):
        super().__init__(index)

    def getFeatures(self, gameState, action):
        features = {}
        successor = self.getSuccessor(gameState, action)
        myState = successor.getAgentState(self.index)
        myPos = myState.getPosition()

        # Computes distance to invaders we can see.
        enemies = [successor.getAgentState(i) for i in self.getOpponents(successor)]
        invaders = [a for a in enemies if a.isPacman() and a.getPosition() is not None]
        ghosts = [a for a in enemies if a.isGhost() and a.getPosition() is not None
                  and not a.isScared()]
        features['numInvaders'] = len(invaders)

        # Computes whether we're on defense (1) or offense (0).
        features['onDefense'] = 0
        if (len(invaders) > 0):
            features['onDefense'] = 1

        if (len(invaders) > 0):
            dists = [self.getMazeDistance(myPos, a.getPosition()) for a in invaders]
            features['invaderDistance'] = min(dists)
            if myState.isScared():
                features['scared'] = min(dists)

        if len(invaders) == 0:
            if len(ghosts) > 0:
                distToGhost = min([(self.getMazeDistance(myPos, g.getPosition())) for g in ghosts])
                features['distanceToGhost'] = distToGhost

        features['pacman'] = 0
        if myState.isPacman():
            features['pacman'] = 1

        if (action == Directions.STOP):
            features['stop'] = 1

        return features

    def getWeights(self, gameState, action):
        return {
            'successorScore': 100,
            'scared': 5,  # initially 10, 5 works
            'distanceToFood': -1,  # initially -1
            'distanceToGhost': -1,  # initially -1, 1
            'numInvaders': -1000,
            'onDefense': 100,
            'invaderDistance': -10,
            'stop': -100,
            'reverse': -2,
            'pacman': -1000  # experimental for defense build
        }

def createTeam(firstIndex, secondIndex, isRed,
        first = 'pacai.student.myTeam.Agent1',
        second = 'pacai.student.myTeam.Agent2'):
    """
    This function should return a list of two agents that will form the capture team,
    initialized using firstIndex and secondIndex as their agent indexed.
    isRed is True if the red team is being created,
    and will be False if the blue team is being created.
    """

    firstAgent = Agent1
    secondAgent = Agent2

    return [
        firstAgent(firstIndex),
        secondAgent(secondIndex),
    ]
